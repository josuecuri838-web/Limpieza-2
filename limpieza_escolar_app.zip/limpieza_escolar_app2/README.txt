LIMPIEZA QUE HACE LA DIFERENCIA — PRIMERA VERSION FUNCIONAL

La pantalla inicial reproduce el video proporcionado y, al terminar, muestra la portada del documento. También se puede pulsar Omitir.

Incluye navegación funcional, registro, menú, encuesta, consejos, información de higiene, reproductor de video y materiales de limpieza.

Para probar: abre index.html en un navegador moderno.

Para convertirlo en APK Android se puede envolver esta interfaz con Android WebView/Capacitor. Los recursos están dentro de assets/ para que funcionen sin internet.
